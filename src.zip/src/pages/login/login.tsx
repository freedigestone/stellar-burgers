import { FC, SyntheticEvent, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { LoginUI } from '@ui-pages';
import { loginUser } from '../../services/userSlice';
import type { AppDispatch, RootState } from '../../services/store';
import { useNavigate, useLocation } from 'react-router-dom';

export const Login: FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();
  const location = useLocation();

  const error = useSelector((state: RootState) => state.user.error);

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: SyntheticEvent) => {
    e.preventDefault();

    try {
      const user = await dispatch(loginUser({ email, password })).unwrap();

      if (!user || !user.email) return;

      // Перенаправление туда, куда хотел попасть пользователь
      const redirect = (location.state as any)?.from?.pathname || '/';
      navigate(redirect);
    } catch (err) {
      // Ошибка уже лежит в state.user.error
      return;
    }
  };

  return (
    <LoginUI
      errorText={error || ''}
      email={email}
      setEmail={setEmail}
      password={password}
      setPassword={setPassword}
      handleSubmit={handleSubmit}
    />
  );
};
