import { FC, SyntheticEvent, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { RegisterUI } from '@ui-pages';
import { registerUser } from '../../services/userSlice';
import type { AppDispatch, RootState } from '../../services/store';
import { useNavigate } from 'react-router-dom';

export const Register: FC = () => {
  const dispatch = useDispatch<AppDispatch>();
  const navigate = useNavigate();

  const error = useSelector((state: RootState) => state.user.error);

  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  /** Submit регистрации */
  const handleSubmit = async (e: SyntheticEvent) => {
    e.preventDefault();

    try {
      const result = await dispatch(
        registerUser({ email, password, name: userName })
      ).unwrap();

      // ⚠ Проверяем success, иначе — ошибка.
      if (!result || !result.email) {
        return;
      }

      navigate('/login'); // успешная регистрация → на логин
    } catch (err) {
      // Ошибка уже записана в store.user.error
      // Редирект НЕ ДЕЛАЕМ.
      return;
    }
  };

  return (
    <RegisterUI
      errorText={error || ''}
      email={email}
      userName={userName}
      password={password}
      setEmail={setEmail}
      setPassword={setPassword}
      setUserName={setUserName}
      handleSubmit={handleSubmit}
    />
  );
};
