export { IngredientsCategory } from './ingredients-category';
