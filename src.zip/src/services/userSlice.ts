import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import {
  loginUserApi,
  registerUserApi,
  logoutApi,
  getUserApi,
  updateUserApi
} from '../utils/burger-api';
import { TUser } from '../utils/types';

interface UserState {
  data: TUser | null;
  isUserLoaded: boolean;
  isLoading: boolean;
  error: string | null;
}

const initialState: UserState = {
  data: null,
  isUserLoaded: false,
  isLoading: false,
  error: null
};

// ---------- LOGIN ----------
export const loginUser = createAsyncThunk(
  'user/login',
  async (form: { email: string; password: string }) => {
    const res = await loginUserApi(form);
    return {
      user: res.user,
      tokens: {
        accessToken: res.accessToken,
        refreshToken: res.refreshToken
      }
    };
  }
);

// ---------- REGISTER ----------
export const registerUser = createAsyncThunk(
  'user/register',
  async (form: { email: string; password: string; name: string }, thunkAPI) => {
    const res = await registerUserApi(form);

    if (!res.success) {
      return thunkAPI.rejectWithValue(res.message);
    }

    return res.user;
  }
);

// ---------- LOGOUT ----------
export const logoutUser = createAsyncThunk('user/logout', async () => {
  await logoutApi();
  return null;
});

// ---------- GET USER ----------
export const getUser = createAsyncThunk('user/getUser', async () => {
  const res = await getUserApi();
  return res.user;
});

// ---------- UPDATE USER ----------
export const updateUser = createAsyncThunk(
  'user/update',
  async (form: { email: string; name: string; password?: string }) => {
    const res = await updateUserApi(form); // 1 объект
    return res.user;
  }
);

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    clearUser(state) {
      state.data = null;
      state.isUserLoaded = true;
    }
  },
  extraReducers: (builder) => {
    builder
      // LOGIN
      .addCase(loginUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data = action.payload;

        // --- сохранить токены ---
        const { accessToken, refreshToken } = action.meta.arg.tokens;
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', refreshToken);
      })
      .addCase(loginUser.rejected, (state) => {
        state.isLoading = false;
        state.error = 'Ошибка входа';
      })

      // REGISTER
      .addCase(registerUser.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.isLoading = false;
        state.data = action.payload;

        // --- сохранить токены ---
        const { accessToken, refreshToken } = action.meta.arg.tokens;
        localStorage.setItem('accessToken', accessToken);
        localStorage.setItem('refreshToken', refreshToken);
      })

      .addCase(registerUser.rejected, (state) => {
        state.isLoading = false;
        state.error = 'Ошибка регистрации';
      })

      // LOGOUT
      .addCase(logoutUser.fulfilled, (state) => {
        state.data = null;
      })

      // GET USER
      .addCase(getUser.fulfilled, (state, action) => {
        state.data = action.payload;
        state.isUserLoaded = true;
      })
      .addCase(getUser.rejected, (state) => {
        state.data = null;
        state.isUserLoaded = true;
      })

      // UPDATE
      .addCase(updateUser.fulfilled, (state, action) => {
        state.data = action.payload;
      });
  }
});

export const { clearUser } = userSlice.actions;
export default userSlice.reducer;
