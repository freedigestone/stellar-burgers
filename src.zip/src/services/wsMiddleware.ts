import { Middleware } from '@reduxjs/toolkit';
import { wsConnect, wsDisconnect, wsMessage } from './feedSlice';

export const wsMiddleware = (): Middleware => (store) => {
  let socket: WebSocket | null = null;

  return (next) => (action) => {
    const { dispatch } = store;

    if (wsConnect.match(action)) {
      socket = new WebSocket('wss://norma.education-services.ru/orders/all');
    }

    if (wsDisconnect.match(action) && socket) {
      socket.close();
      socket = null;
    }

    if (socket) {
      socket.onmessage = (event) => {
        const data = JSON.parse(event.data);
        dispatch(wsMessage(data));
      };

      socket.onerror = () => {
        console.error('WS error');
      };
    }

    return next(action);
  };
};
